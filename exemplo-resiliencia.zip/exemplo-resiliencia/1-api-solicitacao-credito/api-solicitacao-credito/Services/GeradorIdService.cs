﻿namespace api_solicitacao_credito.Services
{
    public static class GeradorIdService
    {
        private static long _ultimoTimestamp = -1L;
        private static int _contador = 0;
        private static readonly object _bloqueio = new();

        public static long ProximoId()
        {
            var timestamp = ObterTimestampAtual();
            
            if (timestamp < _ultimoTimestamp)
            {
                timestamp = _ultimoTimestamp;
            }

            if (timestamp == _ultimoTimestamp)
            {
                _contador++;
            }
            else
            {
                _contador = 0;
                _ultimoTimestamp = timestamp;
            }

            return timestamp * 10_000L + _contador;
        }

        private static long ObterTimestampAtual()
        {
            return long.Parse(DateTime.UtcNow.ToString("yyyyMMddHHmmss"));
        }
    }
}
