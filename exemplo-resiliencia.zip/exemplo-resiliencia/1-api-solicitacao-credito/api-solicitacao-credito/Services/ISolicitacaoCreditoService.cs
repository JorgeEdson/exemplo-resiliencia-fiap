﻿using api_solicitacao_credito.Dominio;
using api_solicitacao_credito.DTOs;
using api_solicitacao_credito.Infraestrutura.Persistencia;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace api_solicitacao_credito.Services
{
    public interface ISolicitacaoCreditoService
    {
        Task<SalvarSolicitacaoResultado> SalvarSolicitacaoCreditoAsync(
        SalvarSolicitacaoCreditoRequest request,
        CancellationToken cancellationToken = default);
    }

    public record SalvarSolicitacaoResultado(
    bool JaExistia,
    string IdempotencyKey,
    string Mensagem);

    public class SolicitacaoCreditoService : ISolicitacaoCreditoService
    {
        private readonly CreditoDbContext _dbContext;
        private readonly ILogger<SolicitacaoCreditoService> _logger;

        public SolicitacaoCreditoService(
           CreditoDbContext dbContext,
           ILogger<SolicitacaoCreditoService> logger)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<SalvarSolicitacaoResultado> SalvarSolicitacaoCreditoAsync(
           SalvarSolicitacaoCreditoRequest request,
           CancellationToken cancellationToken = default)
        {
            if (request is null)
            {
                _logger.LogError("Request de solicitação de crédito veio nulo.");
                throw new ArgumentNullException(nameof(request));
            }

            _logger.LogInformation(
                "Recebendo solicitação de crédito. IdCliente={IdCliente}, Valor={ValorSolicitado}, Prazo={PrazoMeses}, TipoProduto={TipoProduto}, DataSolicitacao={DataSolicitacao}",
                request.IdCliente,
                request.ValorSolicitado,
                request.PrazoMeses,
                request.TipoProduto,
                request.DataSolicitacao);

            var idempotencyKey = GerarIdempotencyKey(request);

            _logger.LogInformation("IdempotencyKey gerada: {IdempotencyKey}", idempotencyKey);

            var existente = await _dbContext.OutboxMessages
                .AsNoTracking()
                .FirstOrDefaultAsync(o => o.IdempotencyKey == idempotencyKey, cancellationToken);

            if (existente is not null)
            {
                _logger.LogInformation(
                    "Solicitação já existente na Outbox. Id={Id}, IdempotencyKey={IdempotencyKey}",
                    existente.Id,
                    existente.IdempotencyKey);

                return new SalvarSolicitacaoResultado(
                    JaExistia: true,
                    IdempotencyKey: existente.IdempotencyKey,
                    Mensagem: "Solicitação de crédito já havia sido recebida anteriormente.");
            }

            var payloadJson = JsonSerializer.Serialize(request);

            _logger.LogDebug("Payload serializado para Outbox: {Payload}", payloadJson);

            var outbox = new OutboxMessage
            {
                Id = GeradorIdService.ProximoId(),
                IdempotencyKey = idempotencyKey,
                TipoMensagem = "SolicitacaoCreditoCriada",
                Payload = payloadJson,
                Status = OutboxStatus.Pendente,
                DataCriacao = DateTime.UtcNow
            };

            _logger.LogInformation(
                "Criando nova mensagem Outbox. Id={Id}, IdempotencyKey={IdempotencyKey}, Status={Status}",
                outbox.Id,
                outbox.IdempotencyKey,
                outbox.Status);

            _dbContext.OutboxMessages.Add(outbox);

            var linhas = await _dbContext.SaveChangesAsync(cancellationToken);

            _logger.LogInformation(
                "SaveChangesAsync concluído. Linhas afetadas={LinhasAfetadas}",
                linhas);

            return new SalvarSolicitacaoResultado(
                JaExistia: false,
                IdempotencyKey: idempotencyKey,
                Mensagem: "Solicitação de crédito recebida com sucesso e será processada de forma assíncrona.");
        }

        private static string GerarIdempotencyKey(SalvarSolicitacaoCreditoRequest request)
        {
            
            var dataRef = request.DataSolicitacao;

            if (dataRef == default)
                dataRef = DateTime.UtcNow;

            var dataUtc = DateTime.SpecifyKind(dataRef, DateTimeKind.Utc).ToUniversalTime();

            var baseUtc = new DateTime(2020, 1, 1, 0, 0, 0, DateTimeKind.Utc);

            long janela48h = (long)(dataUtc - baseUtc).TotalHours / 48;

            var raw = $"{request.IdCliente}|{request.ValorSolicitado}|{request.PrazoMeses}|{request.TipoProduto}|W{janela48h}";

            using var sha = SHA256.Create();
            var bytes = Encoding.UTF8.GetBytes(raw);
            var hash = sha.ComputeHash(bytes);

            return Convert.ToHexString(hash);
        }

    }
}
