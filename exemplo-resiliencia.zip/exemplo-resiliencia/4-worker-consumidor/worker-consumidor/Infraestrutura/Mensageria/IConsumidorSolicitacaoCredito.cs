﻿

namespace worker_consumidor.Infraestrutura.Mensageria
{
    public interface IConsumidorSolicitacaoCredito
    {   
        Task IniciarAsync(CancellationToken stoppingToken);
    }
}
