﻿using worker_consumidor.DTOs;

namespace worker_consumidor.Dominio
{
    public class SolicitacaoRejeitada
    {
        public long Id { get; set; }

        public long IdCliente { get; set; }
        public decimal ValorSolicitado { get; set; }
        public int PrazoMeses { get; set; }
        public TipoProduto TipoProduto { get; set; }
        public DateTime DataSolicitacao { get; set; }

        public DateTime DataRejeicao { get; set; }

        
        public string MensagemRejeicao { get; set; } = default!;
    }
}
