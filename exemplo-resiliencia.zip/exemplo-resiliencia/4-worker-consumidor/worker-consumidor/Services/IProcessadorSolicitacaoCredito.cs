﻿using System.Text.Json;
using worker_consumidor.Dominio;
using worker_consumidor.DTOs;
using worker_consumidor.Infraestrutura.Persistencia.Propostas;
using worker_consumidor.Infraestrutura.Persistencia.SolicitacoesRejeitadas;

namespace worker_consumidor.Services
{
    public interface IProcessadorSolicitacaoCredito
    {
        Task ProcessarAsync(
            string payloadJson,
            IDictionary<string, object> propriedades,
            CancellationToken cancellationToken);
    }

    public class ProcessadorSolicitacaoCredito : IProcessadorSolicitacaoCredito
    {
        private readonly ILogger<ProcessadorSolicitacaoCredito> _logger;
        private readonly PropostasDbContext _propostasDb;
        private readonly SolicitacoesRejeitadasDbContext _rejeitadasDb;

        public ProcessadorSolicitacaoCredito(
            ILogger<ProcessadorSolicitacaoCredito> logger,
            PropostasDbContext propostasDb,
            SolicitacoesRejeitadasDbContext rejeitadasDb)
        {
            _logger = logger;
            _propostasDb = propostasDb;
            _rejeitadasDb = rejeitadasDb;
        }

        public async Task ProcessarAsync(
            string payloadJson,
            IDictionary<string, object> propriedades,
            CancellationToken cancellationToken)
        {
            _logger.LogInformation(
                "Iniciando processamento da solicitação de crédito. PayloadLength={Length}.",
                payloadJson?.Length ?? 0);

            var dto = JsonSerializer.Deserialize<SolicitarCreditoMensagemDto>(payloadJson, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            });

            if (dto is null)
            {
                _logger.LogError("Falha ao desserializar payload da solicitação de crédito.");
                throw new InvalidOperationException("Payload inválido para solicitação de crédito.");
            }

            // Regra de aprovação simples para demonstração
            bool aprovada;
            string motivoRejeicao = string.Empty;

            if (dto.ValorSolicitado <= 20_000m && dto.PrazoMeses <= 36)
            {
                aprovada = true;
            }
            else
            {
                aprovada = false;
                motivoRejeicao = MontarMotivoRejeicao(dto);
            }

            if (aprovada)
            {
                await TratarAprovadaAsync(dto, cancellationToken);
            }
            else
            {
                await TratarRejeitadaAsync(dto, motivoRejeicao, cancellationToken);
            }
        }

        private async Task TratarAprovadaAsync(
            SolicitarCreditoMensagemDto dto,
            CancellationToken cancellationToken)
        {
            // Para demo, vamos assumir:
            // - ValorAprovado = ValorSolicitado
            // - TaxaJurosAnual depende do tipo de produto
            // - DataPrimeiraParcela = 1 mês após a data da solicitação
            var taxaAnual = ObterTaxaJurosAnual(dto.TipoProduto);

            var valorAprovado = dto.ValorSolicitado;
            var valorParcela = CalcularParcelaPrice(
                valorAprovado,
                taxaAnual,
                dto.PrazoMeses);

            var dataPrimeiraParcela = CalcularDataPrimeiraParcela(dto.DataSolicitacao);

            var proposta = new Proposta
            {
                IdCliente = dto.IdCliente,
                ValorSolicitado = dto.ValorSolicitado,
                PrazoMeses = dto.PrazoMeses,
                TipoProduto = dto.TipoProduto,
                DataSolicitacao = dto.DataSolicitacao,

                ValorAprovado = valorAprovado,
                TaxaJurosAnual = taxaAnual,
                ValorParcela = valorParcela,
                DataPrimeiraParcela = dataPrimeiraParcela,

                DataCriacaoProposta = DateTime.UtcNow,
                StatusProposta = "Aprovada"
            };

            _propostasDb.Propostas.Add(proposta);
            await _propostasDb.SaveChangesAsync(cancellationToken);

            _logger.LogInformation(
                "Proposta aprovada e persistida. IdCliente={IdCliente}, ValorSolicitado={ValorSolicitado}, ValorAprovado={ValorAprovado}, PrazoMeses={PrazoMeses}, TipoProduto={TipoProduto}, TaxaAnual={TaxaAnual}, ValorParcela={ValorParcela}, DataPrimeiraParcela={DataPrimeiraParcela}",
                dto.IdCliente,
                dto.ValorSolicitado,
                valorAprovado,
                dto.PrazoMeses,
                dto.TipoProduto,
                taxaAnual,
                valorParcela,
                dataPrimeiraParcela);
        }

        private async Task TratarRejeitadaAsync(
            SolicitarCreditoMensagemDto dto,
            string motivoRejeicao,
            CancellationToken cancellationToken)
        {
            var rejeitada = new SolicitacaoRejeitada
            {
                IdCliente = dto.IdCliente,
                ValorSolicitado = dto.ValorSolicitado,
                PrazoMeses = dto.PrazoMeses,
                TipoProduto = dto.TipoProduto,
                DataSolicitacao = dto.DataSolicitacao,

                DataRejeicao = DateTime.UtcNow,
                MensagemRejeicao = motivoRejeicao
            };

            _rejeitadasDb.SolicitacoesRejeitadas.Add(rejeitada);
            await _rejeitadasDb.SaveChangesAsync(cancellationToken);

            _logger.LogInformation(
                "Solicitação de crédito rejeitada e persistida. IdCliente={IdCliente}, ValorSolicitado={ValorSolicitado}, PrazoMeses={PrazoMeses}, TipoProduto={TipoProduto}, MotivoRejeicao={Motivo}",
                dto.IdCliente,
                dto.ValorSolicitado,
                dto.PrazoMeses,
                dto.TipoProduto,
                motivoRejeicao);
        }

        private static string MontarMotivoRejeicao(SolicitarCreditoMensagemDto dto)
        {
            if (dto.ValorSolicitado > 20_000m && dto.PrazoMeses > 36)
                return "Valor solicitado acima do limite e prazo maior que o permitido.";

            if (dto.ValorSolicitado > 20_000m)
                return "Valor solicitado acima do limite permitido para este perfil.";

            if (dto.PrazoMeses > 36)
                return "Prazo maior que o permitido para este tipo de crédito.";

            return "Solicitação não atende aos critérios de aprovação.";
        }

        private static decimal ObterTaxaJurosAnual(TipoProduto tipoProduto)
        {
            // Tabela didática de taxas por tipo de produto
            return tipoProduto switch
            {
                TipoProduto.CreditoPessoal => 24.0m,
                TipoProduto.EmprestimoConsignado => 18.0m,
                TipoProduto.FinanciamentoVeicular => 16.0m,
                TipoProduto.FinanciamentoImobiliario => 12.0m,
                TipoProduto.CartaoCredito => 30.0m,
                TipoProduto.AntecipacaoFGTS => 14.0m,
                TipoProduto.CreditoEmpresarial => 20.0m,
                _ => 22.0m
            };
        }

        private static DateTime CalcularDataPrimeiraParcela(DateTime dataSolicitacao)
        {
            // Para demo: primeira parcela 1 mês após a data da solicitação
            var dataBase = DateTime.SpecifyKind(dataSolicitacao, DateTimeKind.Utc);
            return dataBase.AddMonths(1).Date;
        }

        private static decimal CalcularParcelaPrice(
            decimal valor,
            decimal taxaAnualPercent,
            int prazoMeses)
        {
            if (prazoMeses <= 0) return valor;

            // Converte taxa anual em taxa mensal (aproximação simples)
            var taxaMensal = (double)(taxaAnualPercent / 12m / 100m);

            if (taxaMensal <= 0.0)
                return Math.Round(valor / prazoMeses, 2);

            var pv = (double)valor;
            var n = prazoMeses;

            // Fórmula Price: PMT = PV * i / (1 - (1 + i)^-n)
            var numerador = pv * taxaMensal;
            var denominador = 1 - Math.Pow(1 + taxaMensal, -n);

            var pmt = numerador / denominador;

            return Math.Round((decimal)pmt, 2);
        }
    }
}
