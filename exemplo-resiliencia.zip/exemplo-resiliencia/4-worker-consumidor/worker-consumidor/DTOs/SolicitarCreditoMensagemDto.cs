﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace worker_consumidor.DTOs
{
    public class SolicitarCreditoMensagemDto
    {
        public long IdCliente { get; set; }
        public decimal ValorSolicitado { get; set; }
        public int PrazoMeses { get; set; }
        public TipoProduto TipoProduto { get; set; }
        public DateTime DataSolicitacao { get; set; }
    }

    public enum TipoProduto
    {
        CreditoPessoal = 1,
        EmprestimoConsignado = 2,
        FinanciamentoVeicular = 3,
        FinanciamentoImobiliario = 4,
        CartaoCredito = 5,
        AntecipacaoFGTS = 6,
        CreditoEmpresarial = 7
    }
}
