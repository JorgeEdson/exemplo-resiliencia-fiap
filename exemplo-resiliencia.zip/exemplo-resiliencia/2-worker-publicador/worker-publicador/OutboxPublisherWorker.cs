using Microsoft.EntityFrameworkCore;
using Polly;
using worker_publicador.Dominio;
using worker_publicador.Infraestrutura.Mensageria;
using worker_publicador.Infraestrutura.Persistencia;
using worker_publicador.Infraestrutura.Resiliencia;

namespace worker_publicador
{
    public class OutboxPublisherWorker : BackgroundService
    {
        private readonly ILogger<OutboxPublisherWorker> _logger;
        private readonly CreditoDbContext _dbContext;
        private readonly IPublicadorMensagem _publicador;
        private readonly IAsyncPolicy _politicasDeResiliencia;

        public OutboxPublisherWorker(
            ILogger<OutboxPublisherWorker> logger,
            CreditoDbContext dbContext,
            IPublicadorMensagem publisher,
            ILoggerFactory loggerFactory)
        {
            _logger = logger;
            _dbContext = dbContext;
            _publicador = publisher;

            _politicasDeResiliencia = PollyPoliticas.CriarPoliticasDeResiliencia(
                loggerFactory.CreateLogger("Polly.OutboxPublisher"));
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("OutboxPublisherWorker iniciado.");

            var timer = new PeriodicTimer(TimeSpan.FromSeconds(5));

            try
            {
                while (await timer.WaitForNextTickAsync(stoppingToken))
                {
                    await ProcessarMensagensPendentesAsync(stoppingToken);
                }
            }
            catch (OperationCanceledException)
            {
                _logger.LogInformation("OutboxPublisherWorker cancelado.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro inesperado no OutboxPublisherWorker.");
            }
        }

        private async Task ProcessarMensagensPendentesAsync(CancellationToken cancellationToken)
        {
            var pendentes = await _dbContext.OutboxMessages
                .Where(o => o.Status == OutboxStatus.Pendente)
                .OrderBy(o => o.DataCriacao)
                .Take(50)
                .ToListAsync(cancellationToken);

            if (!pendentes.Any())
            {
                _logger.LogDebug("Nenhuma mensagem pendente na Outbox.");
                return;
            }

            _logger.LogInformation("Encontradas {Quantidade} mensagens pendentes na Outbox.", pendentes.Count());

            foreach (var outbox in pendentes)
            {
                try
                {
                    await _politicasDeResiliencia.ExecuteAsync(async ct =>
                    {
                        await _publicador.PublicarAsync(outbox, ct);
                    }, cancellationToken);

                    outbox.Status = OutboxStatus.Publicada;
                    outbox.DataAtualizacao = DateTime.UtcNow;

                    _logger.LogInformation(
                        "Mensagem Outbox publicada com sucesso. OutboxId={OutboxId}",
                        outbox.Id);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex,
                        "Falha ao publicar mensagem Outbox. OutboxId={OutboxId}. Ser� tentado novamente na pr�xima itera��o.",
                        outbox.Id);                    
                }
            }

            await _dbContext.SaveChangesAsync(cancellationToken);
        }
    }
}
