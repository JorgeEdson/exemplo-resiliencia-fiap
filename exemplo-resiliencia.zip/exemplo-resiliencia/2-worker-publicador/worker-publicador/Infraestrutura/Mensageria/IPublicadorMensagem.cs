﻿using Azure.Messaging.ServiceBus;
using System.Diagnostics;
using worker_publicador.Dominio;

namespace worker_publicador.Infraestrutura.Mensageria
{
    public interface IPublicadorMensagem
    {
        Task PublicarAsync(OutboxMessage message, CancellationToken cancellationToken = default);
    }

    public class AzureServiceBusMessagePublisher : IPublicadorMensagem, IAsyncDisposable
    {
        private readonly ILogger<AzureServiceBusMessagePublisher> _logger;
        private readonly ServiceBusClient _client;
        private readonly ServiceBusSender _sender;
        private readonly string _queueName;

        public AzureServiceBusMessagePublisher(
              IConfiguration configuration,
              ILogger<AzureServiceBusMessagePublisher> logger)
        {
            _logger = logger;

            var connectionString = configuration["AzureServiceBus:ConnectionString"];
            _queueName = configuration["AzureServiceBus:QueueName"] ?? string.Empty;

            if (string.IsNullOrWhiteSpace(connectionString))
                throw new InvalidOperationException("AzureServiceBus:ConnectionString não configurada.");

            if (string.IsNullOrWhiteSpace(_queueName))
                throw new InvalidOperationException("AzureServiceBus:QueueName não configurada.");

            _logger.LogInformation(
                "Inicializando AzureServiceBusMessagePublisher. Queue={QueueName}",
                _queueName);

            _client = new ServiceBusClient(connectionString);
            _sender = _client.CreateSender(_queueName);

            _logger.LogInformation(
                "AzureServiceBusMessagePublisher pronto. Namespace={Namespace}, Queue={QueueName}",
                _client.FullyQualifiedNamespace,
                _queueName);
        }        

        public async Task PublicarAsync(OutboxMessage message, CancellationToken cancellationToken = default)
        {
            if (message is null)
            {
                _logger.LogError("Tentativa de publicar mensagem nula na fila do Azure Service Bus.");
                throw new ArgumentNullException(nameof(message));
            }

            var payloadLength = message.Payload?.Length ?? 0;

            _logger.LogInformation(
               "Preparando publicação no Azure Service Bus. OutboxId={OutboxId}, TipoMensagem={TipoMensagem}, IdempotencyKey={IdempotencyKey}, PayloadLength={PayloadLength}, Queue={QueueName}",
               message.Id,
               message.TipoMensagem,
               message.IdempotencyKey,
               payloadLength,
               _queueName);

            var sbMessage = new ServiceBusMessage(message.Payload)
            {
                ContentType = "application/json"
            };

            sbMessage.ApplicationProperties["TipoMensagem"] = message.TipoMensagem;
            sbMessage.ApplicationProperties["IdempotencyKey"] = message.IdempotencyKey;
            sbMessage.ApplicationProperties["OutboxId"] = message.Id;

            var stopwatch = Stopwatch.StartNew();

            try
            {
                await _sender.SendMessageAsync(sbMessage, cancellationToken);
                stopwatch.Stop();

                _logger.LogInformation(
                    "Mensagem publicada com sucesso no Azure Service Bus. OutboxId={OutboxId}, Queue={QueueName}, ElapsedMs={ElapsedMs}",
                    message.Id,
                    _queueName,
                    stopwatch.ElapsedMilliseconds);
            }
            catch (ServiceBusException sbEx)
            {
                stopwatch.Stop();

                _logger.LogError(sbEx,
                    "Erro do Azure Service Bus ao publicar mensagem. OutboxId={OutboxId}, Queue={QueueName}, IsTransient={IsTransient}, ElapsedMs={ElapsedMs}",
                    message.Id,
                    _queueName,
                    sbEx.IsTransient,
                    stopwatch.ElapsedMilliseconds);
                
                throw;
            }
            catch (Exception ex)
            {
                stopwatch.Stop();

                _logger.LogError(ex,
                    "Erro inesperado ao publicar mensagem no Azure Service Bus. OutboxId={OutboxId}, Queue={QueueName}, ElapsedMs={ElapsedMs}",
                    message.Id,
                    _queueName,
                    stopwatch.ElapsedMilliseconds);

                throw;
            }
        }

        public async ValueTask DisposeAsync()
        {
            _logger.LogInformation("Liberando recursos do AzureServiceBusMessagePublisher.");

            await _sender.DisposeAsync();
            await _client.DisposeAsync();

            _logger.LogInformation("Recursos do AzureServiceBusMessagePublisher liberados com sucesso.");
        }
    }
}
