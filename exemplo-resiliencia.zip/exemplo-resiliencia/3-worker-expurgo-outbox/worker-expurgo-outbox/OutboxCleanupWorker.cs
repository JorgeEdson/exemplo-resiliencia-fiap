using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using worker_expurgo_outbox.Dominio;
using worker_expurgo_outbox.Infraestrutura.Persistencia;

namespace worker_expurgo_outbox
{
    public class OutboxCleanupWorker : BackgroundService
    {
        private readonly ILogger<OutboxCleanupWorker> _logger;
        private readonly CreditoDbContext _dbContext;
        private readonly OutboxCleanupSettings _settings;

        public OutboxCleanupWorker(
            ILogger<OutboxCleanupWorker> logger,
            CreditoDbContext dbContext,
            IOptions<OutboxCleanupSettings> settings)
        {
            _logger = logger;
            _dbContext = dbContext;
            _settings = settings.Value;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation(
                "OutboxCleanupWorker iniciado. DaysToKeep={DaysToKeep}. Execu��o di�ria programada para 23:00.",
                _settings.DaysToKeep);

            while (!stoppingToken.IsCancellationRequested)
            {
                var agora = DateTime.Now; // hor�rio local do container
                var proximaExecucao = CalcularProximaExecucao(agora);

                var delay = proximaExecucao - agora;

                _logger.LogInformation(
                    "Pr�xima execu��o do expurgo da Outbox agendada para {ProximaExecucao} (em {DelayHoras} horas).",
                    proximaExecucao,
                    delay.TotalHours);

                try
                {
                    // Espera at� o pr�ximo hor�rio (23h)
                    await Task.Delay(delay, stoppingToken);
                }
                catch (OperationCanceledException)
                {
                    _logger.LogInformation("OutboxCleanupWorker cancelado durante o agendamento.");
                    break;
                }

                // Quando chegar o hor�rio, executa o expurgo
                try
                {
                    await ExecutarExpurgoAsync(stoppingToken);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Erro ao executar expurgo da Outbox.");
                }
            }
        }

        private static DateTime CalcularProximaExecucao(DateTime agora)
        {
            // Define o targetDateTime para as 23:00 de hoje.
            DateTime targetDateTime = agora.Date.AddHours(23);

            // Se a hora atual j� passou das 23:00 de hoje, a pr�xima execu��o � as 23:00 de amanh�.
            if (agora >= targetDateTime)
            {
                targetDateTime = targetDateTime.AddDays(1);
            }

            return targetDateTime;
        }

        private async Task ExecutarExpurgoAsync(CancellationToken cancellationToken)
        {
            var limite = DateTime.UtcNow.AddDays(-_settings.DaysToKeep);

            _logger.LogInformation(
                "Iniciando expurgo da Outbox. Ser�o removidas mensagens com Status= Publicada e DataCriacao < {LimiteUtc}.",
                limite);

            var query = _dbContext.OutboxMessages
               .Where(o =>
                   o.Status == OutboxStatus.Publicada &&
                   o.DataAtualizacao.HasValue &&
                   o.DataAtualizacao < limite);

            var removidos = await query.ExecuteDeleteAsync(cancellationToken);

            _logger.LogInformation(
                "Expurgo da Outbox conclu�do. Registros removidos={Quantidade}.",
                removidos);
        }
    }
}
