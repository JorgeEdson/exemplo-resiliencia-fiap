IF DB_ID('SolicitacaoCreditoDb') IS NULL
BEGIN
    CREATE DATABASE SolicitacaoCreditoDb;
END
GO

USE SolicitacaoCreditoDb;
GO

IF OBJECT_ID('dbo.OutboxMessages', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.OutboxMessages
    (
        Id BIGINT NOT NULL PRIMARY KEY,
        IdempotencyKey NVARCHAR(200) NOT NULL,
        TipoMensagem NVARCHAR(100) NOT NULL,
        Payload NVARCHAR(MAX) NOT NULL,
        Status INT NOT NULL,
        DataCriacao DATETIME2 NOT NULL,
        DataAtualizacao DATETIME2 NULL
    );

    CREATE INDEX IX_Outbox_IdempotencyKey
        ON dbo.OutboxMessages(IdempotencyKey);
END
GO
